function init() {
  memoryGameCards();
}

function memoryGameCards() {
  const defaultCard = "front";

  const images = [
    { id: 1, url: "eekhoorn" },
    { id: 2, url: "eendje" },
    { id: 3, url: "egel" },
    { id: 4, url: "flamingos" },
    { id: 5, url: "geit" },
    { id: 6, url: "giraffe" },
    { id: 7, url: "hond" },
    { id: 8, url: "ijsbeer" },
    { id: 9, url: "kat" },
    { id: 10, url: "kittens" },
    { id: 11, url: "kwal" },
    { id: 12, url: "lama" },
    { id: 13, url: "leeuw" },
    { id: 14, url: "nijlpaard" },
    { id: 15, url: "olifant" },
    { id: 16, url: "panda" },
    { id: 17, url: "papegaai" },
    { id: 18, url: "pinguin" },
    { id: 19, url: "schildpad" },
    { id: 20, url: "tijger" },
    { id: 21, url: "zebra" },
    { id: 22, url: "wolf" },
    { id: 23, url: "vogels" },
    { id: 24, url: "uil" },
    { id: 25, url: "stokstaartje" },
    { id: 26, url: "rhino" },
    { id: 27, url: "pauw" },
    { id: 28, url: "rendieren" },
    { id: 29, url: "dolphijn" },
    { id: 30, url: "apen" },
    { id: 31, url: "apen2" },
    { id: 32, url: "beer" },
  ];
}

function randomOrder(images) {}

function flipCard(images) {}

function checkMatch(flippedCards) {}

init();
